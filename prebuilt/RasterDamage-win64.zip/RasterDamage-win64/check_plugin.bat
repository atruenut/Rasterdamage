@echo off
REM Loads RasterDamage.vst3 the way a host scanner does and reports the result.
set P=%~dp0RasterDamage.vst3\Contents\x86_64-win\RasterDamage.vst3
if not exist "%P%" set P=%~dp0RasterDamage.vst3.dll
"%~dp0rd_check.exe" "%P%"
echo.
echo Exit code: %errorlevel%  (0 = loads fine; if it loads here but Reaper ignores it, clear Reaper's plugin cache and re-scan)
pause
